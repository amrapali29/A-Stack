from app import application

if __name__ == "__main__":
    application.run(host='192.168.2.131')
